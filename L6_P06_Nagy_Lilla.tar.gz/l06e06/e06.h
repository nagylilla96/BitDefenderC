#ifndef MODULE_H_MODULE
#define MODULE_H_MODULE
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>

void inverse(FILE *f, FILE *g);

#endif
