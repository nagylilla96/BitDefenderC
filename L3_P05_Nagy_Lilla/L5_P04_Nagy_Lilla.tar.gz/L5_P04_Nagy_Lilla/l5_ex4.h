#ifndef MODULE_H_L5_EX4
#define MODULE_H_L5_EX4
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
#include <math.h>

void convert(int x);
void nullify(int a[]);
int *introduc(int a[], int *n);
void afis(int a[], int n);
int card(int a[], int n);
void reuniune(int a[], int n1, int b[], int n2);
void intersectie(int a[], int n1, int b[], int n2);
void dif(int a[], int n1, int b[], int n2);
int apartine(int a[], int n, int x);

#endif
