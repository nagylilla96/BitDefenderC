#ifndef MODULE_H_MODULE
#define MODULE_H_MODULE
#include <stdlib.h>
#include <stdio.h>

int *read(int *a, int *n);
void write(int *a, int n);
int *subsequence(int *a, int n, int *length);

#endif
