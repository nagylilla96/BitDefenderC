#ifndef MODULE_H_MODULE
#define MODULE_H_MODULE
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

int prim(int x);
int nrLength(int x);
int circular(int x, int n, int isCirc, int it);
int findCirculars(int start, int end);

#endif
