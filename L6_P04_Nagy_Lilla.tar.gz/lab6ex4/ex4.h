#ifndef MODULE_H_MODULE
#define MODULE_H_MODULE
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <limits.h>

void read(FILE *f, int n);
int findstring(char **array, char *string, int nr);

#endif

